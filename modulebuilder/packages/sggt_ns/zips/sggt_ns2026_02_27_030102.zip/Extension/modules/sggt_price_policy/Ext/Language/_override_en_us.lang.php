<?php
// created: 2026-02-26 03:55:10
$mod_strings['LBL_DETAILVIEW_PANEL1'] = 'Other';
