<?php
//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_SGGT_PRICE_POLICY_AOS_PRODUCTS_FROM_SGGT_PRICE_POLICY_TITLE'] = 'Chính sách giá';
$mod_strings['lbl_panel_chinh_sach_gia'] = 'CHÍNH SÁCH GIÁ';
$mod_strings['LBL_PANEL_CHINH_SACH_GIA'] = 'Chính sách giá';
$mod_strings['LBL_PRICE_POLICY_DISPLAY'] = 'Danh sách chính sách giá';
$mod_strings['LBL_PRICE_POLICY_LINES'] = 'Chính sách giá';