<?php
//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_SGGT_PRICE_POLICY_AOS_PRODUCTS_FROM_SGGT_PRICE_POLICY_TITLE'] = 'Chính sách giá';
$mod_strings['lbl_panel_chinh_sach_gia'] = 'PRICE POLICY';
$mod_strings['LBL_PANEL_CHINH_SACH_GIA'] = 'Price Policy';
$mod_strings['LBL_PRICE_POLICY_DISPLAY'] = 'Price Policy List';
$mod_strings['LBL_PRICE_POLICY_LINES'] = 'Price Policy';