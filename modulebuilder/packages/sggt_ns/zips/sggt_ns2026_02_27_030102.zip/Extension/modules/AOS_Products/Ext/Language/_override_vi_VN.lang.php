<?php
// created: 2026-02-26 03:46:51
$mod_strings['LBL_WEIGHT'] = 'Khối lượng (g)';
