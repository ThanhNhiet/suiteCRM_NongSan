<?php
// created: 2026-02-26 03:10:52
$dictionary["AOS_Products"]["fields"]["sggt_price_policy_aos_products"] = array (
  'name' => 'sggt_price_policy_aos_products',
  'type' => 'link',
  'relationship' => 'sggt_price_policy_aos_products',
  'source' => 'non-db',
  'module' => 'sggt_price_policy',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_SGGT_PRICE_POLICY_AOS_PRODUCTS_FROM_SGGT_PRICE_POLICY_TITLE',
);
