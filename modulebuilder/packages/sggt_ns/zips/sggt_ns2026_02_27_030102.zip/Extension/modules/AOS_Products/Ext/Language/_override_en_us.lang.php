<?php
// created: 2026-02-26 03:47:32
$mod_strings['LBL_WEIGHT'] = 'weight (g)';
