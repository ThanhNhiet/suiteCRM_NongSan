<?php
 // created: 2026-02-26 03:30:26
$dictionary['AOS_Products']['fields']['weight_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['weight_c']['labelValue']='weight';

 ?>