<?php 
$app_list_strings['product_type_dom'] = array (
  'Good' => 'Good',
  'Service' => 'Service',
  'Box' => 'Hộp',
);